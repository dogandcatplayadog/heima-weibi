//
//  HWConst.h
//  黑马微博2期
//
//  Created by apple on 14-10-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

// 账号信息
extern NSString * const HWAppKey;
extern NSString * const HWRedirectURI;
extern NSString * const HWAppSecret;

// 通知
// 表情选中的通知
extern NSString * const HWEmotionDidSelectNotification;
extern NSString * const HWSelectEmotionKey;

// 删除文字的通知
extern NSString * const HWEmotionDidDeleteNotification;