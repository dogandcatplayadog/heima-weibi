//
//  HWConst.m
//  黑马微博2期
//
//  Created by apple on 14-10-25.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <Foundation/Foundation.h>

// 账号信息
NSString * const HWAppKey = @"1555496058";
NSString * const HWRedirectURI = @"https://api.weibo.com/oauth2/default.html";
NSString * const HWAppSecret = @"66f6f629895d5d16b4ebe901d3b7a38c";

// 通知
// 表情选中的通知
NSString * const HWEmotionDidSelectNotification = @"HWEmotionDidSelectNotification";
NSString * const HWSelectEmotionKey = @"HWSelectEmotionKey";

// 删除文字的通知
NSString * const HWEmotionDidDeleteNotification = @"HWEmotionDidDeleteNotification";